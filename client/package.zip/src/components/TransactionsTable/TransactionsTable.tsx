import { ActionIcon, Box, Table } from '@mantine/core'
import { TrashIcon } from '@primer/octicons-react';
import { IconEdit } from '@tabler/icons';
import { Transaction } from '../../App';

function TransactionsTable(props: { transactions: Transaction[]; }) {
    return <Table verticalSpacing="xs" fontSize="md" mb={12}>
    <thead>
      <tr>
        <th>Descrição</th>
        <th>Valor</th>
        <th>Categoria</th>
        <th>Data</th>
        <th>Excluir</th>
        <th>Editar</th>
      </tr>
    </thead>
    <tbody>
      {props.transactions.map((transaction) => (
        <tr key={transaction.id}>
          <td>{transaction.title}</td>
          <td className={transaction.isDeposit ? 'isDeposit' : 'withDraw'}>
            {transaction.value}
          </td>
          <td>{transaction.category}</td>
          <td>{new Intl.DateTimeFormat('pt-BR', {}).format(
            new Date(transaction.createdAt)
          )}
          </td>
          <td>
            <ActionIcon variant="transparent" color="red"><TrashIcon size={16} /></ActionIcon>
          </td>
          <td>
            <ActionIcon variant="transparent" color="orange"><IconEdit size={16} /></ActionIcon>
          </td>
        </tr>
      ))}
    </tbody>
  </Table>
}

export default TransactionsTable;